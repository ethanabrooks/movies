I chose to divide my model into 3 Python scripts: main, data, and model. Main is
primarily responsible for handling user interaction and organizing the behaviors
of the other scripts. Data is responsible for parsing the dataset --
specifically, converting the data from its original text form to numpy arrays or
Tensorflow tensors. Finally, model implements the actual architecture of the
autoencoder.

This breakdown anticipates three major changes to the program as a whole:
changes in the way the program interacts with the user, changes in the dataset,
and finally, changes in the model architecture. The goal is to minimally couple
these three parts of the program so that any of these changes would only require
modifications to one of the three scripts. 

The optional task that my model implements is to identifier "outlier" ratings --
meaning ratings that most deviate from the model's predictions. In order to do
this, the model simply calculates the difference between its predicted ratings
and the user's actual ratings. These outlier ratings will be the ones that the
model has not learned to predict because they are anamolous and not
representative of many users.
